const { override, addBabelPlugin } = require('customize-cra');

module.exports = override(
  addBabelPlugin([
    'module-resolver',
    {
      root: ['./src'],
      alias: {
        '@components': './src/components',
        '@pages': './src/pages',
        '@hooks': './src/hooks',
        '@routes': './src/routes',
        '@sections': './src/sections',
        '@layouts': './src/layouts',
        '@redux': './src/redux',
        '@utils': './src/utils',
        '@assets': './src/assets'
      }
    }
  ])
);
