const path = require('path');

module.exports = {
  webpack: {
    alias: {
      '@components': path.resolve(__dirname, 'src/components'),
      '@pages': path.resolve(__dirname, 'src/pages'),
      '@hooks': path.resolve(__dirname, 'src/hooks'),
      '@routes': path.resolve(__dirname, 'src/routes'),
      '@sections': path.resolve(__dirname, 'src/sections'),
      '@layouts': path.resolve(__dirname, 'src/layouts'),
      '@redux': path.resolve(__dirname, 'src/redux'),
      '@utils': path.resolve(__dirname, 'src/utils'),
      '@assets': path.resolve(__dirname, 'src/assets'),
    },
    configure: (webpackConfig) => {
      // Ignore source map warnings from specific packages
      webpackConfig.ignoreWarnings = [
        {
          module: /react-datepicker|stylis-plugin-rtl/,
          message: /Failed to parse source map/
        },
      ];
      return webpackConfig;
    }
  }
};
