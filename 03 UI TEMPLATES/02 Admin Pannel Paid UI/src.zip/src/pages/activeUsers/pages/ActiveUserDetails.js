import { Box, CardContent, Container, Divider, Grid, Typography } from '@mui/material';
import { PATH_DASHBOARD } from '@routes/paths';
import { Helmet } from 'react-helmet-async';

import CustomBreadcrumbs from '@components/custom-breadcrumbs';
import { useSettingsContext } from '@components/settings';

import { useLocation } from 'react-router';

import CasinoTable from '../components/CasionoTable';
import TransactionTable from '../components/TransactionTable';
import SportsTable from '../components/SportsTable';

export default function ActiveUserDetails() {
  const { themeStretch } = useSettingsContext();
    const {  state } = useLocation();
  
  // const { userDetails } = useSelector((store) => store?.users);

  const userDetails = state

  return (
    <>
      <Helmet>
        <title> User Details: List | ODDS </title>
      </Helmet>

      <Container maxWidth={themeStretch ? false : 'lg'}>
        <CustomBreadcrumbs
          heading="User Details"
          links={[
            { name: 'Dashboard', href: PATH_DASHBOARD.root },
            { name: 'User List', href: PATH_DASHBOARD.user.list },
            { name: userDetails?.username },
          ]}
        />

        {/* <Card sx={{ borderRadius: 2, boxShadow: 3, mb: 5 }}> */}
          <CardContent>
            <Typography variant="h5" gutterBottom>
              User Details
            </Typography>
            <Divider sx={{ mb: 2 }} />
            
            <Grid  spacing={10} sx={{mt: 2 }} >
              {[
                { label: 'User Name', value: userDetails?.username },
                userDetails.email && { label: 'Email', value: userDetails?.email },
                userDetails?.balance && { label: 'Balance', value: `${userDetails?.balance}` },
                userDetails?.totalDeposit &&{ label: 'Total Deposit', value: userDetails?.totalDeposit },
                userDetails?.totalWithdrawal && { label: 'Total Withdrawal', value: userDetails?.totalWithdrawal },
                userDetails?.totalNewProfit &&{ label: 'Total NewProfit', value: userDetails?.totalNewProfit },
              ].filter(Boolean).map((item, index) => (
                <Grid item xs={12} sm={6} md={6} key={index} mt={2}>
                  <Box sx={{ display: 'flex', alignItems: 'center', columnGap: 1.5 }}>
                    <Typography variant='body2' sx={{ width: "150px" }}>
                      {item.label}
                    </Typography>
                    <Typography variant="body1"><strong>{item.value}</strong></Typography>
                  </Box>
                </Grid>
              ))}
            </Grid>


            {/* <Grid container spacing={1}>
              <Grid item xs={12} md={6} lg={6} >
                <Typography variant="subtitle2" color="text.secondary">
                  Username
                </Typography>
              </Grid>
              <Grid item xs={12} md={6} lg={6}>
                <Typography>{userDetails?.username}</Typography>
              </Grid>

              <Grid item xs={12} md={6} lg={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Email
                </Typography>
              </Grid>
              <Grid item xs={12} md={6} lg={6}>
                <Typography>{userDetails?.email}</Typography>
              </Grid>

              <Grid item xs={12} md={6} lg={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Balance
                </Typography>
              </Grid>
              <Grid item xs={12} md={6} lg={6}>
                <Typography>{userDetails?.balance}</Typography>
              </Grid>
              <Grid item xs={12} md={6} lg={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Total Deposit
                </Typography>
              </Grid>
              <Grid item xs={12} md={6} lg={6}>
                <Typography>{userDetails?.totalDeposit}</Typography>
              </Grid>
              <Grid item xs={12} md={6} lg={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Total Withdrawal
                </Typography>
              </Grid>
              <Grid item xs={12} md={6} lg={6}>
                <Typography>{userDetails?.totalWithdrawal}</Typography>
              </Grid>
              <Grid item xs={12} md={6} lg={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Total NewProfit
                </Typography>
              </Grid>
              <Grid item xs={12} md={6} lg={6}>
                <Typography>{userDetails?.totalNewProfit}</Typography>
              </Grid>
            </Grid> */}
          </CardContent>
        {/* </Card> */}

        <SportsTable data={userDetails?.sportsBets} />
        <CasinoTable data={userDetails?.casinoBets} />
        <TransactionTable data={userDetails?.transactions} />
      </Container>
    </>
  );
}
