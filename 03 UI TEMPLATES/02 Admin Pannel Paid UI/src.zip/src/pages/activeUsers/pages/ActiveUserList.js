import {
  Card,
  Container,
  Table,
  TableBody,
  TableContainer,
} from '@mui/material';
import { PATH_DASHBOARD } from '@routes/paths';
import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import CustomBreadcrumbs from '@components/custom-breadcrumbs';
import Scrollbar from '@components/scrollbar';
import { useSettingsContext } from '@components/settings';
import {
  TableHeadCustom,
  TableNoData,
  useTable,
} from '@components/table';

import { getActiveUsersAsync } from '@redux/services';
import { useDispatch, useSelector } from 'react-redux';

import ActiveUserTableRow from '../components/ActiveUserTableRow';
// ----------------------------------------------------------------------

const TABLE_HEAD = [
  { id: 'sno.', label: 'S No.', align: 'left' },
  { id: 'userName.', label: 'Username', align: 'left' },
  { id: 'action', label: 'Action', align: 'left' },
];

const size = localStorage.getItem('table-rows-per-page') ?? 10;
const DEFAULT_QUERY = { page: 1, size: Number(size) };

export default function ActiveUserListPage() {

  const {
    dense,
    order,
    orderBy,
    selected,
    setSelected,
    onSort,
  } = useTable();

  const { themeStretch } = useSettingsContext();

  const { activeUsers, isLoading } = useSelector((store) => store?.users);
  const dispatch = useDispatch();

  const [query, setQuery] = useState(DEFAULT_QUERY);

  const [filters, setFilters] = useState({
    userName: '',
  });

  const handleReset = () => {
    const resetFilters = { userName: '' };
    setFilters(resetFilters);
    setQuery({ page: 1, size: query?.size });

    const payload = { page: 1, size: query.size, ...resetFilters };
    dispatch(getActiveUsersAsync(payload));
  };

  useEffect(() => {
    if (orderBy === 'walletbalance' && order === 'asc') {
      setQuery((p) => {
        p.page = 1;
        p.size = query.size;
        p.sort = order;
        return { ...p };
      });
      const payload = { page: 1, size: query.size, sortBy: 'balance', ...filters };
      dispatch(getActiveUsersAsync(payload));
    } else if (orderBy === 'walletbalance' && order === 'desc') {
      setQuery((p) => {
        p.page = 1;
        p.size = query.size;
        return { ...p };
      });
      const payload = { page: 1, size: query.size, ...filters };

      dispatch(getActiveUsersAsync(payload));
    }
  }, [dispatch, orderBy, order, filters, query.size]);

  useEffect(() => {
    setSelected([]);

    const fetchData = () => {
      const payload = { page: query.page, size: query.size };
      dispatch(getActiveUsersAsync(payload));
    };

    fetchData(); // Initial fetch

    const interval = setInterval(() => {
      fetchData();
    }, 60000); // 60 seconds

    return () => clearInterval(interval); // Cleanup on unmount
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch, query.page, query.size]);

  return (
    <>
      <Helmet>
        <title>Active User: List | ODDS </title>
      </Helmet>

      <Container maxWidth={themeStretch ? false : 'lg'}>
        <CustomBreadcrumbs
          heading="Active User List"
          links={[
            { name: 'Dashboard', href: PATH_DASHBOARD.root },
            { name: 'Active User', href: PATH_DASHBOARD.activeUser.list },
            { name: 'List' },
          ]}
        />

        <Card>
          <TableContainer sx={{ position: 'relative', overflow: 'unset' }}>
            <Scrollbar>
              <Table size={dense ? 'small' : 'medium'} sx={{ minWidth: 800 }}>
                <TableHeadCustom
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={activeUsers?.length}
                  numSelected={selected.length}
                  onSort={onSort}
                />

                <TableBody>
                  {!isLoading && activeUsers?.map((row, index) => (
                    <ActiveUserTableRow
                      key={row._id}
                      row={row}
                      index={index}
                      onReset={handleReset}
                    />
                  ))}

                  <TableNoData isNotFound={!isLoading && activeUsers.length === 0} isLoading={isLoading} />
                </TableBody>
              </Table>
            </Scrollbar>
          </TableContainer>
        </Card>
      </Container>
    </>
  );
}
