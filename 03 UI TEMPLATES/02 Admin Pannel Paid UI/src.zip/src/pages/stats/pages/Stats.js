import {
  Box,
  Card,
  CardContent,
  CircularProgress,
  Container,
  Divider,
  Grid,
  Stack,
  Tab,
  Table,
  TableContainer,
  Tabs,
  Typography,
} from '@mui/material';
import Scrollbar from '@components/scrollbar';

import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { TableHeadCustom, useTable } from '@components/table';
import CustomBreadcrumbs from '@components/custom-breadcrumbs';
import { Helmet } from 'react-helmet-async';
import { PATH_DASHBOARD } from '@routes/paths';
import { useSettingsContext } from '@components/settings';
import { getRelationShipManagerAsync, getSalesAgentAsync } from '@redux/services';
import { getStatsAsync } from '@redux/services/statsService';
import AppDatePicker from '@components/datepicker/AppDatePicker';
import dayjs from 'dayjs';
import { clearStatsData } from '@redux/slices/statsSlice';
import StatsTable from '../components/StatsTable';
import StatsToolbar from '../components/StatsToolbar';
import SalesDetails from '../components/SalesDetails';

const TABLE_HEAD = [
  { id: 'sno', label: 'S No.', align: 'left', minWidth: '100px' },
  { id: 'userName', label: 'User Name', align: 'left' },
  { id: 'email', label: 'Email', align: 'left' },
  { id: 'totalDeposit', label: 'Total Deposit', align: 'left' },
  { id: 'totalWithdraw', label: 'Total Withdraw', align: 'left' },
];
const TABLE_HEAD_SALES_DETAILS = [
  { id: 'sno', label: 'S No.', align: 'left', minWidth: '100px' },
  { id: 'agent', label: 'Agent Name', align: 'left' },
  { id: 'totalUsers', label: 'Total Users', align: 'left' },
  { id: 'totalDeposit', label: 'Total Deposit', align: 'left' },
  { id: 'totalWithdraw', label: 'Total Withdraw', align: 'left' },
  { id: 'totalNumberOfDeposits', label: 'Total Number Of Deposits', align: 'left' },
  { id: 'totalNumberOfWithdraws', label: 'Total Number Of Withdraws', align: 'left' },
];

export default function Stats() {
  const { themeStretch } = useSettingsContext();
  const { dense, order, orderBy } = useTable();
  const [search, setSearch] = useState({});

  const { relationshipManager, salesAgent } = useSelector((state) => state.users);

  const dispatch = useDispatch();
  const { statsData, isLoading } = useSelector((store) => store.stats);
  const [range, setRange] = useState('all');
  const [fromDate, setFromDate] = React.useState('');
  const [toDate, setToDate] = React.useState('');
  const handleTabChange = (event, newValue) => {
    setRange(newValue);
    dispatch(clearStatsData());
  };
  const handleReset = () => {
    setSearch(null);
    setRange('all');
  };

  useEffect(() => {
    dispatch(getRelationShipManagerAsync());
    dispatch(getSalesAgentAsync());
  }, [dispatch]);

  useEffect(() => {
    if (range === 'dayWise') {
      if (fromDate && toDate) {
        const payload = {
          startDate: dayjs(fromDate).format('YYYY-MM-DD'),
          endDate: dayjs(toDate).format('YYYY-MM-DD'),
          ...search,
        };
        dispatch(getStatsAsync(payload));
      }
    } else if (search?.salesAgent || search?.rm) {
      dispatch(getStatsAsync({ filterType: range, ...search }));
    } else {
      dispatch(getStatsAsync({ filterType: range }));
    }
  }, [dispatch, fromDate, range, search, toDate]);

  return (
    <>
      <Helmet>
        <title> Sales Stats: List | ODDS </title>
      </Helmet>

      <Container maxWidth={themeStretch ? false : 'lg'}>
        <CustomBreadcrumbs
          heading="Sales Stats"
          links={[{ name: 'Dashboard', href: PATH_DASHBOARD.root }, { name: 'Sales Stats' }]}
        />

        <Box sx={{ borderBottom: 1, borderColor: 'divider', mt: 2 }}>
          <Tabs
            value={range}
            onChange={handleTabChange}
            aria-label="range tabs"
            textColor="primary"
            indicatorColor="primary"
            sx={{
              margin: 1,

              '& .MuiTab-root': {
                // Default background color for tabs
                backgroundColor: 'transparent',
                transition: 'background-color 0.3s ease', // Smooth transition
              },
              // '& .Mui-selected': {
              //   border:1

              // },
            }}
          >
            <Tab label="All" value="all" />
            <Tab label="Daily" value="daily" />
            <Tab label="Weekly" value="weekly" />
            <Tab label="Monthly" value="monthly" />
            <Tab label="Date" value="dayWise" />
          </Tabs>
        </Box>

        {range === 'dayWise' && (
          <Box>
            <Stack spacing={2} direction="row" mt={2}>
              <Box
                rowGap={3}
                columnGap={2}
                display="grid"
                gridTemplateColumns={{
                  xs: 'repeat(1, 1fr)',
                  sm: 'repeat(2, 1fr)',
                }}
                sx={{ p: 3, width: '100%' }}
              >
                <Stack>
                  <AppDatePicker
                    placeholderText="From Date"
                    selected={fromDate}
                    onChange={(date) => setFromDate(date)}
                    maxDate={new Date()}
                  />
                </Stack>
                <Stack>
                  <AppDatePicker
                    placeholderText="To Date"
                    selected={toDate}
                    onChange={(date) => setToDate(date)}
                    minDate={fromDate}
                    maxDate={new Date()}
                  />
                </Stack>
              </Box>
            </Stack>
          </Box>
        )}

        <StatsToolbar
          relationshipManagerList={relationshipManager}
          salesAgentList={salesAgent}
          setSearch={setSearch}
          handleReset={handleReset}
        />
        <Divider sx={{ my: 2 }} />
        {isLoading ? (
          <div
            style={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              height: '10vh',
            }}
          >
            <CircularProgress />
          </div>
        ) : (
          <>
            <CardContent>
              <Grid spacing={10} sx={{ my: 2 }}>
                {[
                  statsData?.totalDeposit != null && {
                    label: 'Total Deposit',
                    value: statsData.totalDeposit,
                  },
                  statsData?.totalNumberOfDeposits != null && {
                    label: 'Total Number Of Deposits',
                    value: statsData.totalNumberOfDeposits,
                  },
                  statsData?.totalNumberOfWithdraws != null && {
                    label: 'Total Number Of Withdraws',
                    value: statsData.totalNumberOfWithdraws,
                  },
                  statsData?.totalUsers != null && {
                    label: 'Total Users',
                    value: statsData.totalUsers,
                  },
                  statsData?.totalWithdraw != null && {
                    label: 'Total Withdrawal',
                    value: statsData.totalWithdraw,
                  },
                  statsData?.rm && { label: 'Relationship Manager', value: statsData.rm },
                  statsData?.salesAgent && { label: 'Sales Agent', value: statsData.salesAgent },
                ]
                  .filter(Boolean)
                  .map((item, index) => (
                    <Grid item xs={12} sm={6} md={6} key={index} my={2}>
                      <Box sx={{ display: 'flex', alignItems: 'center', columnGap: 1.5 }}>
                        <Typography variant="body2" sx={{ width: '150px' }}>
                          {item.label}
                        </Typography>
                        <Typography variant="body1">
                          <strong>{item.value}</strong>
                        </Typography>
                      </Box>
                    </Grid>
                  ))}
              </Grid>
              <Divider sx={{ my: 2 }} />
            </CardContent>
            <Card>
              <TableContainer sx={{ position: 'relative', overflow: 'unset' }}>
                <Scrollbar>
                  {statsData?.userDetails?.length ? (
                    <Table stickyHeader size={dense ? 'small' : 'medium'} sx={{ minWidth: 800 }}>
                      <TableHeadCustom order={order} orderBy={orderBy} headLabel={TABLE_HEAD} />
                      {statsData?.userDetails?.map((item, index) => (
                        <StatsTable data={item} index={index} />
                      ))}
                    </Table>
                  ) : null}
                  {statsData?.salesDetails?.length ? (
                    <Table stickyHeader size={dense ? 'small' : 'medium'} sx={{ minWidth: 800 }}>
                      <TableHeadCustom
                        order={order}
                        orderBy={orderBy}
                        headLabel={TABLE_HEAD_SALES_DETAILS}
                      />
                      {statsData?.salesDetails?.map((item, index) => (
                        <SalesDetails data={item} index={index} />
                      ))}
                    </Table>
                  ) : null}
                </Scrollbar>
              </TableContainer>
            </Card>
          </>
        )}
      </Container>
    </>
  );
}
