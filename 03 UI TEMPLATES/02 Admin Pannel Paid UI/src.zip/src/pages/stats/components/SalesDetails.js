/* eslint-disable react/prop-types */
/* eslint-disable react/jsx-no-useless-fragment */
import {
  TableBody,
  TableCell,
  TableRow,
} from '@mui/material'
import { TableNoData } from '@components/table'

export default function SalesDetails ({ data, index }) {

  return (
    <TableBody>
      <TableRow hover>
        <TableCell align='left'>{index+1}</TableCell>
        <TableCell align='left' sx={{ textTransform: 'capitalize' }}>{data?.agent || '-'}</TableCell>
        <TableCell align='left'>{data?.totalUsers || '-'}</TableCell>
        <TableCell align='left'>{data?.totalDeposit || '-'}</TableCell>
        <TableCell align='left'>{data?.totalWithdraw || '-'}</TableCell>
        <TableCell align='left'>{data?.totalNumberOfDeposits || '-'}</TableCell>
        <TableCell align='left'>{data?.totalNumberOfWithdraws || '-'}</TableCell>
      </TableRow>
      {(!data || data.length === 0) && <TableNoData isNotFound />}
    </TableBody>
  )
}
