/* eslint-disable react/prop-types */
/* eslint-disable react/jsx-no-useless-fragment */
import {
  TableBody,
  TableCell,
  TableRow,
} from '@mui/material'
import { TableNoData } from '@components/table'

export default function StatsTable ({ data, index }) {

  return (
    <TableBody>
      <TableRow hover>
        <TableCell align='left'>{index+1}</TableCell>
        <TableCell align='left' sx={{ textTransform: 'capitalize' }}>{data?.userName || '-'}</TableCell>
        <TableCell align='left'>{data?.email || '-'}</TableCell>
        <TableCell align='left'>{data?.totalDeposit || '-'}</TableCell>
        <TableCell align='left'>{data?.totalWithdraw || '-'}</TableCell>
      </TableRow>
      {(!data || data.length === 0) && <TableNoData isNotFound />}
    </TableBody>
  )
}
