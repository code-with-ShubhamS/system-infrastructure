import FormProvider, { RHFAutocomplete } from '@components/hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { LoadingButton } from '@mui/lab'
import { Box, Grid, Stack } from '@mui/material'
import PropTypes from 'prop-types'
import { useForm } from 'react-hook-form'
import { useSelector } from 'react-redux'
import * as Yup from 'yup'

StatsToolbar.propTypes = {
  relationshipManagerList: PropTypes.any,
  salesAgentList: PropTypes.any,
  setSearch: PropTypes.func,
  handleReset: PropTypes.func,
}

export default function StatsToolbar ({ relationshipManagerList, salesAgentList, setSearch, handleReset }) {
  const FilterSchema = Yup.object().shape({
    relationshipManager: Yup.object().nullable(),
    salesAgent: Yup.object().nullable(),
  })

  const { isSubmitting } = useSelector(state => state.playersBet)

  const methods = useForm({
    resolver: yupResolver(FilterSchema),
    defaultValues: {
      relationshipManager: null,
      salesAgent: null,
    },
  })

  const { handleSubmit, reset } = methods

  const onSubmit = async data => {
    setSearch({
      rm: data?.relationshipManager?.name || '',
      salesAgent: data?.salesAgent?.name || '',
    })
  }

  return (
    <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
      <Grid container>
        <Box
          rowGap={3}
          columnGap={2}
          display='grid'
          gridTemplateColumns={{
            xs: 'repeat(1, 1fr)',
            sm: 'repeat(2, 1fr)',
          }}
          sx={{ p: 3, width: '100%' }}
        >
          <RHFAutocomplete
            name='relationshipManager'
            label='Relationship Manager'
            options={relationshipManagerList}
            getOptionLabel={option => option?.name || ''}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                onSubmit();
              }
            }}
          />

          <RHFAutocomplete
            name='salesAgent'
            label='Sales Agent'
            options={salesAgentList || []}
            getOptionLabel={option => option?.name || ''}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                onSubmit();
              }
            }}
          />
        </Box>
        <Stack flexDirection="row" gap={1} justifyContent="flex-end"  width='100%' paddingRight={3}>
        <Box>
          <LoadingButton type='submit' variant='contained' loading={isSubmitting}>
            Search
          </LoadingButton>
        </Box>
        <Box>
          <LoadingButton variant='contained' loading={isSubmitting} onClick={() =>  { reset();handleReset()}} color='error'>
            Reset
          </LoadingButton>
        </Box>
        </Stack>
      </Grid>
    </FormProvider>
  )
}
