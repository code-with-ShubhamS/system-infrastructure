import FormProvider, { RHFAutocomplete } from '@components/hook-form';
import { useSnackbar } from '@components/snackbar';
import { yupResolver } from '@hookform/resolvers/yup';
import { LoadingButton } from '@mui/lab';
import { Box, Card, Grid, Stack, Typography } from '@mui/material';
import { useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import * as Yup from 'yup';
import { setFancyDefaultAsync } from '@redux/services/playersBet';
import { getAllEnabledMatchStausAsync } from '@redux/services/matchStatus';

export default function FancyDefaultForm() {
  const dispatch = useDispatch();
  const { isfancyDefaultLoading } = useSelector((state) => state.playersBet);
  const { enqueueSnackbar } = useSnackbar();
  const { matchStatusList } = useSelector((state) => state.matchStatus);

  const matchStatusSchema = Yup.object().shape({
    matchId: Yup.mixed().required('Match Id is required'),
    status: Yup.string().required('Status is required'),
  });

  const defaultValues = useMemo(
    () => ({
      matchId: null,
      status: '',
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const methods = useForm({
    resolver: yupResolver(matchStatusSchema),
    defaultValues,
  });

  const { reset, handleSubmit } = methods;

  const onSubmit = async (data) => {
    const payload = {
      id: data.matchId?.eventId,
      status: data?.status,
    };

    try {
      const response = await dispatch(
        setFancyDefaultAsync({ id: payload.id, data: { status: payload.status } })
      );

      // eslint-disable-next-line radix
      if (parseInt(response.payload?.responseCode) === 200) {
        enqueueSnackbar(response.payload?.responseMessage || 'Fancy Default status update successfully!', {
          variant: 'success',
          autoHideDuration: 5000,
          anchorOrigin: {
            vertical: 'top',
            horizontal: 'right',
          },
        });
        reset();
      }
    } catch (error) {
      enqueueSnackbar(error.message || 'Failed to update match status!', { variant: 'error' });
      console.error(error);
    }
  };

  useEffect(() => {
    dispatch(getAllEnabledMatchStausAsync({ enabled: true }));
  }, [dispatch]);

  return (
    <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={3} mt={5}>
        <Card sx={{ p: 3, width: '100%' }}>
          <Typography variant="h4" gutterBottom>
            Set Fancy Default
          </Typography>
          <Box
            rowGap={3}
            columnGap={2}
            display="grid"
            gridTemplateColumns={{
              xs: 'repeat(1, 1fr)',
              sm: 'repeat(2, 1fr)',
            }}
          >
            <RHFAutocomplete
              name="matchId"
              label="Match Id"
              options={matchStatusList}
              getOptionLabel={(option) => option?.eventName || ''}
              isOptionEqualToValue={(option, value) => option.eventId === value.eventId}
            />

            <RHFAutocomplete
              name="status"
              label="Status"
              options={['true', 'false']}
              getOptionLabel={(option) =>
              option ? option.charAt(0).toUpperCase() + option.slice(1) : ''}
              isOptionEqualToValue={(option, value) => option === value}
            />

            
          </Box>
          <Stack gap="10px" justifyContent="flex-end" flexDirection="row" sx={{ mt: 3 }}>
            <LoadingButton type="submit" variant="contained" loading={isfancyDefaultLoading}>
              Submit
            </LoadingButton>
          </Stack>
        </Card>
      </Grid>
    </FormProvider>
  );
}
