import FormProvider, { RHFAutocomplete } from '@components/hook-form';
import { useSnackbar } from '@components/snackbar';
import { yupResolver } from '@hookform/resolvers/yup';
import { LoadingButton } from '@mui/lab';
import { Box, Card, Grid, Stack, Typography, TextField } from '@mui/material';
import { useEffect, useMemo } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import * as Yup from 'yup';
import { setMatchLimitAsync } from '@redux/services/playersBet';
import { getAllEnabledMatchStausAsync } from '@redux/services/matchStatus';

export default function MatchBetLimitForm() {
  const dispatch = useDispatch();
  const { matchLimitLoading } = useSelector((state) => state.playersBet);
  const { enqueueSnackbar } = useSnackbar();
  const { matchStatusList } = useSelector((state) => state.matchStatus);

  const matchStatusSchema = Yup.object().shape({
    matchId: Yup.mixed().required('Match Id is required'),
    maxBetLimit: Yup.number().typeError('Amount must be a number').required('Amount is required'),
  });

  const defaultValues = useMemo(
    () => ({
      matchId: null,
      maxBetLimit: '',
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const methods = useForm({
    resolver: yupResolver(matchStatusSchema),
    defaultValues,
  });

  const { reset, handleSubmit } = methods;

  const onSubmit = async (data) => {
    const payload = {
      id: data.matchId?.eventId,
      maxBetLimit: data?.maxBetLimit,
    };
    console.log('payload', payload);

    try {
      const response = await dispatch(
        setMatchLimitAsync({ id: payload.id, data: { maxBetLimit: payload.maxBetLimit } })
      );

      // eslint-disable-next-line radix
      if (parseInt(response.payload?.responseCode) === 200) {
        enqueueSnackbar(response.payload?.responseMessage || 'Match status update successfully!', {
          variant: 'success',
          autoHideDuration: 5000,
          anchorOrigin: {
            vertical: 'top',
            horizontal: 'right',
          },
        });
        reset();
      }
    } catch (error) {
      enqueueSnackbar(error.message || 'Failed to update match status!', { variant: 'error' });
      console.error(error);
    }
  };

  useEffect(() => {
    dispatch(getAllEnabledMatchStausAsync({ enabled: true }));
  }, [dispatch]);

  return (
    <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={3} mt={5}>
        <Card sx={{ p: 3, width: '100%' }}>
          <Typography variant="h4" gutterBottom>
            Set Match limit
          </Typography>
          <Box
            rowGap={3}
            columnGap={2}
            display="grid"
            gridTemplateColumns={{
              xs: 'repeat(1, 1fr)',
              sm: 'repeat(2, 1fr)',
            }}
          >
            <RHFAutocomplete
              name="matchId"
              label="Match Id"
              options={matchStatusList}
              getOptionLabel={(option) => option?.eventName || ''}
              isOptionEqualToValue={(option, value) => option.eventId === value.eventId}
            />

            <Controller
              name="maxBetLimit"
              control={methods.control}
              render={({ field, fieldState: { error } }) => (
                <TextField
                  {...field}
                  label="Max Bet Limit"
                  type="number"
                  fullWidth
                  variant="outlined"
                  error={!!error}
                  helperText={error?.message}
                />
              )}
            />
          </Box>
          <Stack gap="10px" justifyContent="flex-end" flexDirection="row" sx={{ mt: 3 }}>
            <LoadingButton type="submit" variant="contained" loading={matchLimitLoading}>
              Submit
            </LoadingButton>
          </Stack>
        </Card>
      </Grid>
    </FormProvider>
  );
}
