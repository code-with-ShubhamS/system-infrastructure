
import React from 'react'

const index = () => {
    <div>index</div>
}

export default index