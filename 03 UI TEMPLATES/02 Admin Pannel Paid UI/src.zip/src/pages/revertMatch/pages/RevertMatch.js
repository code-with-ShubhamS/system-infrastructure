import CustomBreadcrumbs from '@components/custom-breadcrumbs';
import { useSettingsContext } from '@components/settings';
import { Container } from '@mui/material';
import { Helmet } from 'react-helmet-async';
import RevertMatchForm from '../component/RevertMatchForm';


export default function RevertMatch() {
  const { themeStretch } = useSettingsContext();


  return (
    <>
      <Helmet>
        <title>Revert Match</title>
      </Helmet>

      <Container maxWidth={themeStretch ? false : 'lg'}>
        <CustomBreadcrumbs
          heading='Revert Match'
          links={[
            {
              name: 'Revert Match',
            },
          ]}
        />
        <RevertMatchForm />
      </Container>
    </>
  );
}
