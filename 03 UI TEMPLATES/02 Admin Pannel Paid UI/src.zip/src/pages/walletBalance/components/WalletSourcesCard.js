/* eslint-disable react/prop-types */
import { Box, Card, Divider, Grid, Typography } from '@mui/material'
import React from 'react'

const WalletSourcesCard = ({ walletSources }) => {
  const colors = [
    '#5C6BC0', // deep indigo (muted but rich)
    '#26A69A', // teal (darker)
    '#EF5350', // softer red
    '#FFA726', // rich orange
    '#AB47BC', // deeper purple
    '#42A5F5', // blue (consistent with your chart)
    '#66BB6A', // soft green
    '#EC407A', // dark pink
  ]

  return (
    <Box sx={{ mt: 2 }}>
      <Typography variant='h5' py={2}>
        Sources
      </Typography>
      <Divider sx={{ mb: 4 }} />
      <Grid container spacing={2}>
        {Object.entries(walletSources || {}).map(([key, value], index) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={key}>
            <Card
              sx={{
                p: 2,
                backgroundColor: colors[index % colors.length],
                color: '#fff',
                minHeight: 100,
                borderRadius: 2,
                boxShadow: 3,
                minWidth: 200,
              }}
            >
              <Typography variant='subtitle1' sx={{ fontWeight: 'bold' }}>
                {key || '-'}
              </Typography>
              <Typography variant='h6'>₹{value?.totalBalance?.toLocaleString('en-IN')}</Typography>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  )
}

export default WalletSourcesCard
