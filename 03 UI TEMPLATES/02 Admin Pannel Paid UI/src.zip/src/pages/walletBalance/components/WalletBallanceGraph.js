/* eslint-disable import/no-extraneous-dependencies */
import { Card, Typography, Box } from '@mui/material';
import PropTypes from 'prop-types';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';

WalletBalanceGraph.propTypes = {
  data: PropTypes.object,
};

const COLORS = ['#1976d2', '#e0e0e0']; // filled, remaining

export default function WalletBalanceGraph({ data }) {
  const balance = Number(data?.highBalance) || 0;
  const maxBalance = 100000;

  const chartData = [
    { name: 'Balance', value: balance },
    { name: 'Remaining', value: Math.max(maxBalance - balance, 0) },
  ];

  return (
    <Card
      sx={{
        p: 3,
        maxWidth: 450,
        mx: 'auto',
        boxShadow: 4,
        borderRadius: 2,
        backgroundColor: '#f0f4f8',
        textAlign: 'center',
        my:6
      }}
    >
      <Typography variant="subtitle1" fontWeight={700} gutterBottom>
        Highest Wallet Balance
      </Typography>

      <Box sx={{ height: 240, position: 'relative' }}>
        <ResponsiveContainer>
          <PieChart>
            <Pie
              data={chartData}
              innerRadius="70%"
              outerRadius="100%"
              dataKey="value"
              startAngle={90}
              endAngle={-270}
              paddingAngle={2}
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index]} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value) => [`₹${value}`, '']}
              contentStyle={{ fontSize: 13 }}
            />
          </PieChart>
        </ResponsiveContainer>

        {/* Center label */}
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
          }}
        >
          <Typography variant="h5" fontWeight={700}>
            ₹{balance.toLocaleString()}
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{textTransform: "capitalize"}}>
            {data?.userNameWithHighBalance || 'N/A'}
          </Typography>
        </Box>
      </Box>
    </Card>
  );
}
