import {
  Box,
  CardContent,
  CircularProgress,
  Container,
  Divider,
  Grid,
  Typography,
} from '@mui/material'

import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getWalletBalanceAsync } from '@redux/services/walletService'
import CustomBreadcrumbs from '@components/custom-breadcrumbs'
import { Helmet } from 'react-helmet-async'
import { PATH_DASHBOARD } from '@routes/paths'
import { useSettingsContext } from '@components/settings'
import WalletBallanceGraph from '../components/WalletBallanceGraph'
import WalletSourcesCard from '../components/WalletSourcesCard'

export default function WalletBallance () {
  const { themeStretch } = useSettingsContext()

  const dispatch = useDispatch()
  const { walletBalance, isLoading } = useSelector(store => store.walletBalance)

  useEffect(() => {
    dispatch(getWalletBalanceAsync())
  }, [dispatch])

  return (
    <>
      <Helmet>
        <title> Wallet Ballance: List | ODDS </title>
      </Helmet>

      <Container maxWidth={themeStretch ? false : 'lg'}>
        <CustomBreadcrumbs
          heading='Wallet Ballance'
          links={[{ name: 'Dashboard', href: PATH_DASHBOARD.root }, { name: 'Wallet Ballance' }]}
        />

        <CardContent>
          <Typography variant='h5' gutterBottom>
            Wallet Ballance
          </Typography>
          <Divider sx={{ mb: 2 }} />

          {isLoading ? (
            <div
              style={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                height: '10vh',
              }}
            >
              <CircularProgress />
            </div>
          ) : (
            <Grid spacing={10} sx={{ mt: 2 }}>
              <Grid item xs={12} sm={6} md={6} mt={2}>
                <Box sx={{ display: 'flex', alignItems: 'center', columnGap: 1.5 }}>
                  <Typography variant='body2' sx={{ width: '150px' }}>
                    Total Wallet Ballance
                  </Typography>
                  <Typography variant='body1'>
                    <strong>{walletBalance.totalWalletBalance}</strong>
                  </Typography>
                </Box>
                <Box>
                  <WalletBallanceGraph data={walletBalance} />
                  <WalletSourcesCard walletSources={walletBalance?.sources} />
                </Box>
              </Grid>
            </Grid>
          )}
        </CardContent>
      </Container>
    </>
  )
}
