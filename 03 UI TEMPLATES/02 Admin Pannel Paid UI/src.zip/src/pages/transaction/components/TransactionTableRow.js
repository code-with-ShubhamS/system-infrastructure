import PropTypes from 'prop-types';

// @mui
import {
  Autocomplete,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Menu,
  MenuItem,
  TableCell,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import { Icon } from '@iconify/react';
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router';
import { PATH_DASHBOARD } from '@routes/paths';
import { dispatch } from '@redux/store';
import FormProvider, { RHFTextField } from '@components/hook-form';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import toast from 'react-hot-toast';
import { postPaymentPartialAproveAsync, postPaymentStatusAsync } from '@redux/services/transaction';
import { LoadingButton } from '@mui/lab';
import { useSelector } from 'react-redux';
import ConfirmDialog from '@components/confirm-dialog';
import { formatDate } from '@utils/formatTime';

// ----------------------------------------------------------------------

UserTableRow.propTypes = {
  row: PropTypes.object,
  index: PropTypes.number,
  selected: PropTypes.bool,
  onEditRow: PropTypes.func,
  onViewRow: PropTypes.func,
  onDeleteRow: PropTypes.func,
  onSelectRow: PropTypes.func,
  onReset: PropTypes.func,
};
export const USER_TABLE_DATA = [
  {
    userName: 'u123',
    email: 'player1@example.com',
    phoneNumber: '1234567890',
    twoFactorEnabled: 'false',
    createdAt: '01-03-2025',
  },
  {
    userName: 'u456',
    email: 'player2@example.com',
    phoneNumber: '9876543210',
    twoFactorEnabled: 'true',
    createdAt: '03-03-2025',
  },
  {
    userName: 'u789',
    email: 'player3@example.com',
    phoneNumber: '4567891230',
    twoFactorEnabled: 'false',
    createdAt: '03-03-2025',
  },
];
export default function UserTableRow({ row, selected, index, onReset }) {
  const {
    username,
    transactionId,
    transactionType,
    amount,
    transactionStatus,
    currencyType,
    admin,
    source,
    initiatedAt,
    completedAt,
  } = row;

  const { isPaymentWalletBallanceLoading } = useSelector((state) => state.transactions);

  const [anchorEl, setAnchorEl] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState('');
  const [withdrawalOpen, setWithDrawalOpen] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);

  const navigate = useNavigate();

  // ✅ Open Menu
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  // ✅ Close Menu
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleOpenDialog = (type) => {
    setDialogType(type);
    setDialogOpen(true);
    methods.reset();
    handleClose();
  };

  const handleWithdrawalDialog = (type) => {
    setDialogType(type);
    setDialogOpen(true);
    methods.reset();
    handleClose();
  };

  const handleOpenWithdrawlDialog = (type) => {
    setDialogType(type);
    setDialogOpen(true);
    methods.reset();
    handleClose();
  };

  const handleCloseDialog = () => {
    methods.reset();
    setDialogOpen(false);
  };

  const UserSchema = Yup.object().shape({
    approvedAmount: Yup.number()
      .typeError('Amount must be a number')
      .required('Amount is required'),
    // currency: Yup.string().required('Currency is required'),
    // source: Yup.string().required('Source is required'),
  });

  const defaultValues = useMemo(
    () => ({
      approvedAmount: '',
      // currency: '',
      // source: '',
    }),
    []
  );

  const methods = useForm({
    resolver: yupResolver(UserSchema),
    defaultValues,
  });

  const {
    handleSubmit,
    formState: { isSubmitting },
  } = methods;

  const onSubmit = async (data) => {
    try {
      console.log('data :>> ', data);
      const payload = {
        ...data,
        decision: 'PARTIAL_APPROVE',
        transactionId,
      };

      dispatch(postPaymentPartialAproveAsync(payload)).then((response) => {
        if (response?.payload?.responseCode === 200 || response?.payload?.responseCode === '200') {
          toast.success(
            response?.payload?.responseMessage || 'Transaction status updated successfully!',
            {
              position: 'top-right',
            }
          );
          handleCloseDialog();
        }
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleStatusDialog = (type) => {
    setConfirmOpen(true);
    setDialogType(type);
  };

  const handleStatusApiCall = (data) => {
    const payload = {
      ...data,
      transactionId,
    };

    console.log('payload===>', payload);

    dispatch(postPaymentStatusAsync(payload))
      .then((response) => {
        console.log('response :>> ', response);
        console.log('response :>> ', response?.payload);
        if (response?.payload?.responseCode === 200 || response?.payload?.responseCode === '200') {
          toast.success(
            response?.payload?.responseMessage || 'Transaction status updated successfully!',
            {
              position: 'top-right',
            }
          );
          setConfirmOpen(false);
          onReset();
        } else {
          // toast.error(
          //   response?.payload?.responseMessage || 'Failed to update transaction status!',
          //   {
          //     position: 'top-right',
          //   }
          // );
        }
      })
      .catch((error) => {
        console.error('Error updating transaction status:', error);
      });
  };

  const handleUpdatePayment = () => {
    console.log('handleUpdatePayment');
    if (dialogType === 'Approve') {
      handleStatusApiCall({
        decision: 'APPROVE',
      });
    } else if (dialogType === 'Reject') {
      handleStatusApiCall({
        decision: 'REJECT',
      });
    } else if (dialogType === 'APPROVE & PAY'){
      handleStatusApiCall({
        decision: 'APPROVE_PAY',
      });
    }
  };

  const handleDetailsClick = () => {
    navigate(PATH_DASHBOARD.user.userdetails(row?.userId));
    // navigate(PATH_DASHBOARD.user.userdetails);
  };

  // useEffect(() => {
  //   dispatch(getUserAmountAsync({}))
  // },[]);

  const canPay = (transactionStatus === 'PENDING' && transactionType === 'DEBIT')

  return (
    <TableRow hover selected={selected}>
      <TableCell align="left">{transactionId}</TableCell>
      <TableCell align="left">{username}</TableCell>
      <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
        {amount}
      </TableCell>
      <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
        {currencyType}
      </TableCell>
      <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
        {/* <Label variant="soft" color={transactionStatus === 'SUCCESS' ? 'success' : 'error'} >
        {transactionStatus || '-'}
      </Label> */}
        <div
          style={{
            backgroundColor:
              (transactionStatus === 'SUCCESS' && '#dcf7e8') ||
              (transactionStatus === 'PENDING' && '#ffeed2') ||
              (transactionStatus === 'REJECT' && '#ffc3b6') ||
              (transactionStatus === 'PROCESSING' && '#b7c6ff'),
            textAlign: 'center',
            padding: '2px',
            borderRadius: '5px',
          }}
        >
          <Typography
            variant="subtitle2"
            noWrap
            sx={{
              textTransform: 'capitalize',
              fontSize: '11px',
              fontWeight: 600,
              color:
                (transactionStatus === 'SUCCESS' && '#4caf50') ||
                (transactionStatus === 'PENDING' && '#ff9800') ||
                (transactionStatus === 'REJECT' && '#f44336') ||
                (transactionStatus === 'PROCESSING' && '#3654f4'),
                padding: '2px',
            }}
          >
            {transactionStatus}
          </Typography>
        </div>
      </TableCell>
      <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
        {transactionType}
      </TableCell>
      <TableCell align="left" >
        {admin}
      </TableCell>
      <TableCell align="left">
        {source}
      </TableCell>
      <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
        {initiatedAt ? formatDate(row?.initiatedAt) : "-"}
      </TableCell>
      <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
        {completedAt ? formatDate(row?.completedAt) : "-"}
      </TableCell>
      <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
        <IconButton onClick={() => { if (canPay) handleStatusDialog('Approve'); }} color='success' style={{ color: !canPay && 'gray'}}>
          <Icon icon="mdi:approve" width="24" height="24" />
        </IconButton>
        <IconButton onClick={() => { if (canPay) handleStatusDialog('Reject')}} color='error' style={{ color: !canPay && 'gray'}}>
          <Icon icon="material-symbols:cancel" width="24" height="24" />
        </IconButton>
        <IconButton 
        onClick={() => {if (canPay) handleOpenDialog('Partial Approval')}} 
        color='warning' style={{ color: !canPay && 'gray'}}>
          <Icon icon="material-symbols:stroke-partial" width="24" height="24" />
        </IconButton>
        <IconButton onClick={() => {if (canPay) handleStatusDialog('APPROVE & PAY')}} color='error' style={{ color: !canPay && 'gray'}}>
          <Icon icon="streamline-freehand:money-cash-bill" width="24" height="24" />
        </IconButton>
      </TableCell>

      <FormProvider methods={methods}>
        <Dialog open={dialogOpen} onClose={handleCloseDialog} fullWidth maxWidth="sm">
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogTitle>{dialogType}</DialogTitle>
            <DialogContent>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mb: 2, flex: 1 }}>
                <RHFTextField name="approvedAmount" placeholder="Amount" />

                {/* <Box
                    sx={{
                      display: 'flex',
                      flexDirection: { xs: 'column', sm: 'row' },
                      gap: 2,
                    }}
                  >
                    <RHFAutocomplete
                      name="currency"
                      label="currency"
                      options={amountOptions || []}
                      // getOptionLabel={(option) => option?.runnerName || ''}
                      sx={{ flex: 1 }}
                    />

                    <RHFAutocomplete
                      name="source"
                      label="Source"
                      options={sourceOptions || []}
                      // getOptionLabel={(option) => option?.runnerName || ''}
                      sx={{ flex: 1 }}
                    />
                  </Box> */}
              </Box>
            </DialogContent>

            <DialogActions>
              <Button
                onClick={handleCloseDialog}
                color="secondary"
                variant="outlined"
                disabled={isPaymentWalletBallanceLoading}
              >
                Cancel
              </Button>
              <LoadingButton
                type="submit"
                color="primary"
                disabled={isPaymentWalletBallanceLoading}
                variant="contained"
                loading={isPaymentWalletBallanceLoading}
              >
                {isSubmitting ? 'Submitting...' : 'Submit'}
              </LoadingButton>
            </DialogActions>
          </form>
        </Dialog>

        {/* withdrawal dialog */}

        <Dialog open={withdrawalOpen} onClose={handleCloseDialog} fullWidth maxWidth="sm">
          <form onSubmit={handleSubmit(onSubmit)}>
            <DialogTitle>{dialogType}</DialogTitle>
            <DialogContent>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mb: 2 }}>
                <Controller
                  name="amount"
                  control={methods.control}
                  render={({ field, fieldState: { error } }) => (
                    <TextField
                      {...field}
                      label="Amount"
                      type="number"
                      fullWidth
                      variant="outlined"
                      error={!!error}
                      helperText={error?.message}
                    />
                  )}
                />

                {/* <Box
                    sx={{
                      display: 'flex',
                      flexDirection: { xs: 'column', sm: 'row' },
                      gap: 2,
                      flex: 1
                    }}
                  >
                    <Controller
                      name="currency"
                      control={methods.control}
                      render={({ field, fieldState: { error } }) => (
                        <Autocomplete
                          fullWidth
                          {...field}
                          options={amountOptions}
                          getOptionLabel={(option) => option}
                          onChange={(_, value) => field.onChange(value)}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Currency"
                              error={!!error}
                              helperText={error?.message}
                            />
                          )}
                        />
                      )}
                    />

                    <Controller
                      name="source"
                      control={methods.control}
                      render={({ field, fieldState: { error } }) => (
                        <Autocomplete
                          fullWidth
                          {...field}
                          options={sourceOptions}
                          getOptionLabel={(option) => option}
                          onChange={(_, value) => field.onChange(value)}
                          renderInput={(params) => (
                            <TextField
                              {...params}
                              label="Source"
                              error={!!error}
                              helperText={error?.message}
                            />
                          )}
                        />
                      )}
                    />
                  </Box> */}
              </Box>
            </DialogContent>

            <DialogActions>
              <Button onClick={handleCloseDialog} color="secondary" variant="outlined">
                Cancel
              </Button>
              <Button type="submit" color="primary" disabled={isSubmitting}>
                {isSubmitting ? 'Submitting...' : 'Submit'}
              </Button>
            </DialogActions>
          </form>
        </Dialog>
      </FormProvider>
      <ConfirmDialog
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        title={`Payment ${dialogType}`}
        content={`Are you sure want to ${dialogType} `}
        action={
          <LoadingButton
            variant="contained"
            color="primary"
            onClick={() => handleUpdatePayment()}
            loading={isPaymentWalletBallanceLoading}
          >
            Submit
          </LoadingButton>
        }
      />
    </TableRow>
  );
}
