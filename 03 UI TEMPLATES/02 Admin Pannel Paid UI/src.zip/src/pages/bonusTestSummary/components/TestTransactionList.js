/* eslint-disable react/prop-types */
/* eslint-disable react/jsx-no-useless-fragment */
import {
  Card,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Typography,
} from '@mui/material';
import {
  TableHeadCustom,
  TableNoData,
  useTable,
} from '@components/table';
import { formatDate } from '@utils/formatTime';

const TABLE_HEAD = [
  { id: "serialno", label: "S.No.", align: "left" },
  { id: "admin", label: "Admin", align: "left" },
  { id: 'amount', label: 'Amount', align: 'left' },
  { id: 'currencyType', label: 'Currency Type', align: 'left' },
  { id: 'initiatedAt', label: 'Initiated At', align: 'left' },
  { id: 'source', label: 'Source', align: 'left' },
  { id: 'transactionId', label: 'Transaction Id', align: 'left' },
  { id: 'transactionStatus', label: 'Transaction Status', align: 'left' },
  { id: 'transactionType', label: 'Transaction Type', align: 'left' },
];

export default function TestTransactionList({ data }) {
  const {
    dense,
    order,
    orderBy,
  } = useTable();

  return (
    <Card>
      <Typography variant='h4' sx={{ p: 2 }}>Test Transactions</Typography>
      <TableContainer sx={{ maxHeight: 400, overflow: 'auto' }}>
        <Table stickyHeader size={dense ? 'small' : 'medium'} sx={{ minWidth: 800 }}>
          <TableHeadCustom
            order={order}
            orderBy={orderBy}
            headLabel={TABLE_HEAD}
          />
          <TableBody>
            {data?.map((row, index) => (
              <TableRow hover key={index}>
                <TableCell align="left">{index + 1}</TableCell>
                <TableCell align="left">
                  {row?.admin || '-'}
                </TableCell>
                <TableCell align="left">{row?.amount || '-'}</TableCell>
                <TableCell align="left">{row?.currencyType || '-'}</TableCell>
                <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
                  {row?.initiatedAt ? formatDate(row?.initiatedAt) : "-"}
                </TableCell>
                <TableCell align="left">{row?.source}</TableCell>
                <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
                  {row?.transactionId || '-'}
                </TableCell>
                <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
                {row?.transactionStatus || '-'}
                </TableCell>
                <TableCell align="left" sx={{ textTransform: 'capitalize' }}>
                  {row?.transactionType || '-'}
                </TableCell>
              </TableRow>
            ))}
            {(!data || data.length === 0) && <TableNoData isNotFound />}
          </TableBody>
        </Table>
      </TableContainer>
    </Card> 
  );
}