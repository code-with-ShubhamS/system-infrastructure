import { Box, CardContent, Container, Divider, Grid, Typography } from '@mui/material';
import { PATH_DASHBOARD } from '@routes/paths';
import { useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet-async';

import CustomBreadcrumbs from '@components/custom-breadcrumbs';
import { useSettingsContext } from '@components/settings';

import { useParams } from 'react-router';

import { useDispatch, useSelector } from 'react-redux';
import { getBonusSummaryAsync } from '@redux/services/bonusSummaryService';
import TestTransactionList from '../components/TestTransactionList';
import BonusTransactionList from '../components/BonusTransactionList';
// import { getBonusSummaryAsync } from '@redux/services/bonusSummaryService';

export default function BonusTestSummary() {
  const { themeStretch } = useSettingsContext();
  const { id } = useParams();
  const { bonusSummary } = useSelector((store) => store?.bonusSummary);
  const dispatch = useDispatch();

  const intervalRef = useRef(null); // used to store the interval ID

  // eslint-disable-next-line consistent-return
  useEffect(() => {
      dispatch(getBonusSummaryAsync());
  }, [id, dispatch]);

  return (
    <>
      <Helmet>
        <title> Bonus Test Summary: List | ODDS </title>
      </Helmet>

      <Container maxWidth={themeStretch ? false : 'lg'}>
        <CustomBreadcrumbs
          heading="Bonus Test Summary"
          links={[
            { name: 'Dashboard', href: PATH_DASHBOARD.root },
            { name: 'Bonus Test Summary', href: PATH_DASHBOARD.user.list },
            { name: bonusSummary?.username },
          ]}
        />

          <CardContent>
            <Typography variant="h5" gutterBottom>
              Bonus Test Summary
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Grid  spacing={10} sx={{mt: 2 }} >
                {[
                { label: 'Total Bonus Amount', value: bonusSummary?.totalBonusAmount },
                { label: 'Total Test Amount', value: bonusSummary?.totalTestAmount },
                ].map((item, index) => (
                <Grid item xs={12} sm={6} md={6} key={index} mt={2}>
                    <Box sx={{ display: 'flex', alignItems: 'center', columnGap: 1.5 }}>
                    <Typography variant='body2' sx={{ width: "150px" }}>
                        {item.label}
                    </Typography>
                    <Typography variant="body1"><strong>{item.value}</strong></Typography>
                    </Box>
                </Grid>
                ))}
            </Grid>
          </CardContent>

        <TestTransactionList data={bonusSummary?.testTransactions} />
        <BonusTransactionList data={bonusSummary?.bonusTransactions} />
      </Container>
    </>
  );
}
