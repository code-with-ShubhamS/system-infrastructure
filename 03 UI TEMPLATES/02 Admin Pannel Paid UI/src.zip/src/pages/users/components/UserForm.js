import FormProvider, { RHFTextField, RHFCheckbox, RHFAutocomplete } from '@components/hook-form';
import { useSnackbar } from '@components/snackbar';
import { yupResolver } from '@hookform/resolvers/yup';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { LoadingButton } from '@mui/lab';
import { Box, Card, Grid, IconButton, InputAdornment, Stack } from '@mui/material';
import { addUserAsync, editUserAsync, getRelationShipManagerAsync, getSalesAgentAsync } from '@redux/services';
import { PATH_DASHBOARD } from '@routes/paths';
import PropTypes from 'prop-types';
import { useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import * as Yup from 'yup';

UserForm.propTypes = {
  isEdit: PropTypes.bool,
  isView: PropTypes.bool,
  currentUser: PropTypes.object,
};

export default function UserForm({ isEdit = false, isView = false, currentUser }) {
  const navigate = useNavigate();
  const dispatch = useDispatch();
    const [showPassword, setShowPassword] = useState(false);
    const {relationshipManager, salesAgent} = useSelector((state)=> state.users)

  const { enqueueSnackbar } = useSnackbar();

  const UserSchema = Yup.object().shape({
    userName: Yup.string().required('Username is required'),
    // email: Yup.string().required('Email is required').email('Email must be a valid email address'),
    // phone: Yup.string().required('Phone number is required'),
    password: isEdit ? Yup.string() : Yup.string().required('Password is required'),
  });

  const defaultValues = useMemo(() => {
  const personnel = currentUser?.personnelRecordResponses || [];

  return {
    userName: currentUser?.username || '',
    email: currentUser?.email || '',
    phone: currentUser?.phoneNumber,
    password: currentUser?.password || '',
    twoFactorEnabled: currentUser?.twoFactorEnabled ?? false,
    relationshipManager: personnel.find((p) => p.type === 'RELATIONSHIP_MANAGER') ?? null,
    salesAgent: personnel.find((p) => p.type === 'SALES_AGENT') ?? null,
    isActive: currentUser?.active ?? false,
  };
}, [currentUser]);


  const methods = useForm({
    resolver: yupResolver(UserSchema),
    defaultValues,
  });

  const {
    reset,
    handleSubmit,
    setValue,
    formState: { isSubmitting },
  } = methods;

  useEffect(() => {
    if ((isEdit && currentUser) || (isView && currentUser)) {
      reset(defaultValues);
    }
    if (!isEdit) {
      reset(defaultValues);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isEdit, isView, currentUser]);

  const removeEmptyFields = (obj) =>
  Object.fromEntries(
    Object.entries(obj).filter(
      ([_, value]) => value !== undefined && value !== null && value !== ''
    )
  );

  const onSubmit = async (data) => {

  try {
    const baseFields = {
      email: data.email,
      phoneNumber: data.phone,
      password: data.password,
      relationshipManager: data.relationshipManager?.name,
      salesAgent: data.salesAgent?.name,
    };

    const payload = {
      userName: data.userName,
      twoFactorEnabled: !!data.twoFactorEnabled,
      ...removeEmptyFields(baseFields),
    };

    const editPayload = {
      status: data.isActive,
      ...removeEmptyFields(baseFields),
    };

    const action = isEdit
      ? editUserAsync({ data: editPayload, id: currentUser?.userId })
      : addUserAsync(payload);

    const res = await dispatch(action);

    if (res?.payload) {
      enqueueSnackbar(isEdit ? 'Player updated successfully' : 'Created successfully!');
      if (isEdit) {
        navigate(PATH_DASHBOARD.user.list);
      } else {
        reset();
        navigate(PATH_DASHBOARD.user.list);
      }
    }
  } catch (error) {
    enqueueSnackbar('Something went wrong!');
    console.error(error);
  }
};

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleBack = () => {
    navigate(-1);
  };

  useEffect(()=>{
    dispatch(getRelationShipManagerAsync())
    dispatch(getSalesAgentAsync())
  },[dispatch])

  return (
    <FormProvider methods={methods} onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={3}>
        <Card sx={{ p: 3, width: '100%' }}>
          <Box
            rowGap={3}
            columnGap={2}
            display="grid"
            gridTemplateColumns={{
              xs: 'repeat(1, 1fr)',
              sm: 'repeat(2, 1fr)',
            }}
          >
            {/* <RHFTextField disabled={isView} name="userid" label="UserId" /> */}
            <RHFTextField disabled={isView || isEdit} name="userName" label="Username" />
            <RHFTextField disabled={isView} type="email" name="email" label="Email Address" />
            <RHFTextField
              disabled={isView}
              inputProps={{ maxLength: 10 }}
              name="phone"
              type="number"
              label="Phone Number"
              onChange={(e) => {
                const inputValue = e.target.value.replace(/[^0-9]/g, '').slice(0, 10);

                setValue('phone', inputValue, { shouldValidate: true });
              }}
            />
            <RHFTextField disabled={isView} name="password" label="Password"
            type={showPassword ? 'text' : 'password'}
            InputProps={{endAdornment:
              <InputAdornment position="end">
                <IconButton
                  aria-label={
                    showPassword ? 'hide the password' : 'display the password'
                  }
                  onClick={handleClickShowPassword}
                  edge="end"
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              </InputAdornment>
            }}
             />
            {/* <RHFTextField disabled={isView} name="relationshipManager" label="Relationship Manager" /> */}
            <RHFAutocomplete
              name="relationshipManager"
              label="Relationship Manager"
              options={relationshipManager}
              getOptionLabel={(option) => option?.name}
            />
            <RHFAutocomplete
              name="salesAgent"
              label="Sales Agent"
              options={salesAgent}
              getOptionLabel={(option) => option?.name}
            />
            {/* <RHFTextField disabled={isView} name="salesAgent" label="Sales Agent" /> */}
            <RHFCheckbox disabled={isView || isEdit} name="twoFactorEnabled" label="Two Factor Enabled" />
            {(isView || isEdit) &&
              <RHFCheckbox disabled={isView} name="isActive" label="Is Active"/>
            }
            {/* <RHFTextField disabled={isView} name="created" label="Created At" /> */}
          </Box>

          {isView ? (
            <Stack alignItems="flex-end" sx={{ mt: 3 }}>
              <LoadingButton onClick={handleBack} type="button" variant="contained">
                Back
              </LoadingButton>
            </Stack>
          ) : (
              <Stack gap="10px" justifyContent="flex-end" flexDirection="row" sx={{ mt: 3 }}>
                <LoadingButton type="submit" variant="contained" loading={isSubmitting}>
                  {!isEdit ? 'Create User' : 'Save Changes'}
                </LoadingButton>

                {isEdit && (
                  <LoadingButton
                    onClick={handleBack}
                    type="button"
                    variant="contained"
                    color="error"
                  >
                    Cancel
                  </LoadingButton>
                )}
              </Stack>
          )}
        </Card>
      </Grid>
    </FormProvider>
  );
}
