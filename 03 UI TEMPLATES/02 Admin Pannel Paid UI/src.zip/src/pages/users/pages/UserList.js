import {
  Button,
  Card,
  Container,
  InputAdornment,
  Stack,
  Table,
  TableBody,
  TableContainer,
  TextField,
} from '@mui/material';
import { PATH_DASHBOARD } from '@routes/paths';
import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { Link as RouterLink } from 'react-router-dom';
import CustomBreadcrumbs from '@components/custom-breadcrumbs';
import Iconify from '@components/iconify';
import Scrollbar from '@components/scrollbar';
import { useSettingsContext } from '@components/settings';
import {
  TableHeadCustom,
  TableNoData,
  TablePaginationCustom,
  useTable
} from '@components/table';

import { getUsersAsync } from '@redux/services';
import { useDispatch, useSelector } from 'react-redux';

import { jwtDecode } from 'jwt-decode';
import { UserTableRow } from '../components';
// ----------------------------------------------------------------------

const TABLE_HEAD = [

  { id: "userName.", label: "Username", align: "left" },
  { id: 'email', label: 'Email', align: 'left' },
  { id: 'walletbalance', label: 'Wallet Balance', align: 'left' },
  { id: 'phoneNumber', label: 'Phone Number', align: 'left' },
  { id: 'refCode', label: 'Ref. Code', align: 'left' },
  { id: 'twoFactorEnabled', label: 'Two Factor Enabled', align: 'left' },
  { id: 'action', label: 'Action', align: 'left', minWidth:"200px" },
];


const size = localStorage.getItem('table-rows-per-page') ?? 10;
const DEFAULT_QUERY = { page: 1, size: Number(size) };

export default function UserListPage() {
  const token = localStorage.getItem('token');
  const decoded = jwtDecode(token);

  const {
    dense,
    order,
    orderBy,
    selected,
    setSelected,
    onSort,
    onChangeDense,
    onChangeRowsPerPage,
  } = useTable();

  const { themeStretch } = useSettingsContext();
 
  const { users, totalCount } = useSelector((store) => store?.users);
  const dispatch = useDispatch();

  const [query, setQuery] = useState(DEFAULT_QUERY);


  // const denseHeight = dense ? 52 : 72;
  const isNotFound = (!users.length && !!query?.name) || (!users.length && !!query?.role);

  
  const [filters, setFilters] = useState({
   
    userName: '',
  });


 
  const handleRowsPerPageChange = (event) => {
    const {value} = event.target;
    DEFAULT_QUERY.size = parseInt(value, 10);
    onChangeRowsPerPage(event);
    setQuery((p) => {
      p.page = 1;
      p.size = parseInt(value, 10);
      return { ...p };
    });

     const payload={page: 1, size: value,  ...filters}
    
        dispatch(getUsersAsync(payload));
  };


  const handlePageChange = (event, newPage) => {
    setQuery((p) => {
      p.page = newPage + 1;
      return { ...p };
    });

     const payload={page: newPage + 1, size: query.size,  ...filters}
    
        dispatch(getUsersAsync(payload));
  };

    const handleSearch = () => {
      // onSearch(filters); // call parent search handler
      setQuery({ page: 1, size:query?.size})
      const payload={page: 1, size: query.size, ...filters}
  
      dispatch(getUsersAsync(payload));
    };
  
    const handleReset = () => {
      const resetFilters = {  userName: '' };
      setFilters(resetFilters);
      setQuery({ page: 1, size:query?.size})
    
      const payload={page: 1, size: query.size,  ...resetFilters}
      dispatch(getUsersAsync(payload));
    };
    
    useEffect(() => {
      if (orderBy === "walletbalance" && order === "asc") {
        setQuery((p) => {
          p.page = 1;
          p.size = query.size;
          p.sort = order;
          return { ...p };
        });
        const payload={page: 1, size: query.size, sortBy: "balance", ...filters}
        dispatch(getUsersAsync(payload));

      } else if (orderBy === "walletbalance" && order === "desc") {
        setQuery((p) => {
          p.page = 1;
          p.size = query.size;
          return { ...p };
        });
        const payload={page: 1, size: query.size, ...filters}

        dispatch(getUsersAsync(payload));
      }
    }, [dispatch,orderBy, order, filters, query.size]);
    
    // const onSort2 = (val) => {

    //   if (val === "walletbalance"){
    //     setQuery((p) => {
    //       p.page = 1;
    //       p.size = query.size;
    //       p.sort = val;
    //       return { ...p };
    //     });
    //     const payload={page: 1, size: query.size, sort: val, ...filters}
  
    //     console.log('payload sort===>', payload);

    //   }
    
    //   // dispatch(getUsersAsync(payload));
    // }
  
    

  useEffect(() => {
    setSelected([]);
    const payload={page: query.page, size: query.size}
    dispatch(getUsersAsync(payload));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch, ]);
// console.log(users,'users')
  return (
    <>
      <Helmet>
        <title> User: List | ODDS </title>
      </Helmet>

      <Container maxWidth={themeStretch ? false : 'lg'}>
        <CustomBreadcrumbs
          heading="User Management List"
          links={[
            { name: 'Dashboard', href: PATH_DASHBOARD.root },
            { name: 'User', href: PATH_DASHBOARD.user.list },
            { name: 'List' },
          ]}
          action={
            decoded?.authorities !== 'SUPERADMIN_READ' &&
            <Button
              component={RouterLink}
              to={PATH_DASHBOARD.user.new}
              variant="contained"
              startIcon={<Iconify icon="eva:plus-fill" />}
            >
              New User
            </Button>
          }
        />

        <Card>
        <Stack
      spacing={2}
      alignItems="center"
      direction={{
        xs: 'column',
        sm: 'row',
      }}
      sx={{ px: 2, py: 3 }}
    >

      <TextField
        fullWidth
        size="small"
        value={filters?.userName}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            handleSearch();
          }
        }}
        onChange={(event)=> setFilters((p) => ({ ...p, userName: event.target.value }))}
        placeholder="Search..."
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Iconify icon="eva:search-fill" sx={{ color: 'text.disabled' }} />
            </InputAdornment>
          ),
        }}
      />

      {/* {isFiltered && ( */}
      <Button
        size="small"
        variant="contained"
        color="primary"
        sx={{ height: 40 }}
        onClick={handleSearch}
      >
        Search
      </Button>
      <Button
        size="small"
        variant="contained"
        color="error"
        sx={{ height: 40 }}
        onClick={handleReset}
      >
        Reset
      </Button>
      {/* )} */}
    </Stack>

          <TableContainer sx={{ position: 'relative', overflow: 'unset' }}>
            <Scrollbar>
              <Table size={dense ? 'small' : 'medium'} sx={{ minWidth: 800 }}>
                <TableHeadCustom
                  order={order}
                  orderBy={orderBy}
                  headLabel={TABLE_HEAD}
                  rowCount={users?.length}
                  numSelected={selected.length}
                  onSort={onSort}
                />

                <TableBody>
                  {users?.map((row, index) => (
                    <UserTableRow
                      key={row._id}
                      row={row}
                      index={index}
                      onReset={handleReset}
                    />
                  ))}

                  {/* <TableEmptyRows
                    height={denseHeight}
                    emptyRows={users?.length ? query.size - users.length : 0}
                  /> */}

                  <TableNoData isNotFound={isNotFound} />
                </TableBody>
              </Table>
            </Scrollbar>
          </TableContainer>

          <TablePaginationCustom
            count={totalCount}
            page={query.page - 1}
            rowsPerPage={query?.size}
            onPageChange={handlePageChange}
            onRowsPerPageChange={handleRowsPerPageChange}
            rowsPerPageOptions={[25, 50, 100, 3000]}
            dense={dense}
            onChangeDense={onChangeDense}
          />
        </Card>
      </Container>
    </>
  );
}
