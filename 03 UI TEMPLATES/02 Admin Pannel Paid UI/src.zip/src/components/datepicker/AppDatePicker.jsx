/* eslint-disable arrow-body-style */
/* eslint-disable react/prop-types */
// components/datepicker/AppDatePicker.jsx
import React from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import './DatePickerStyles.css';
import CustomInput from './CustomInput';

const AppDatePicker = ({
  selected,
  onChange,
  dateFormat = 'dd MMM yyyy',
  placeholderText = 'Select a date',
  maxDate,
  minDate,
  showMonthDropdown = false,
  showYearDropdown = false,
  isClearable = false,
  disabled = false,
}) => {
  return (
    <DatePicker
      selected={selected}
      onChange={onChange}
      dateFormat={dateFormat}
      placeholderText={placeholderText}
      maxDate={maxDate}
      minDate={minDate}
      showMonthDropdown={showMonthDropdown}
      showYearDropdown={showYearDropdown}
      isClearable={isClearable}
      disabled={disabled}
      customInput={<CustomInput placeholder={placeholderText} />}
    />
  );
};

export default AppDatePicker;
