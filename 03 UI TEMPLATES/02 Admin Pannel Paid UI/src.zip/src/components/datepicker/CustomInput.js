// CustomInput.js
import React from 'react';
import PropTypes from 'prop-types';

const CustomInput = React.forwardRef(({ value, onClick, placeholder }, ref) => (
  <input
    onClick={onClick}
    value={value}
    placeholder={placeholder}
    ref={ref}
    readOnly
    style={{
      padding: '17px 12px',
      border: '1px solid #ccc',
      borderRadius: '8px',
      width: '100%',
      fontSize: '14px',
      fontFamily: 'Roboto, sans-serif',
      cursor: 'pointer',
    }}
  />
));
CustomInput.propTypes = {
  value: PropTypes.string,
  onClick: PropTypes.func.isRequired,
  placeholder: PropTypes.string,
};

export default CustomInput;
