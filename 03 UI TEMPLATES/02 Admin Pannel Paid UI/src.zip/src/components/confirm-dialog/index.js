export { default } from './ConfirmDialog';
