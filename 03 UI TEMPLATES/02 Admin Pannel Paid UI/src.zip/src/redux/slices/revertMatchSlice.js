// src/redux/slices/revertMatchSlice.js
import { createSlice, isAnyOf } from '@reduxjs/toolkit';
import { revertMatchAsync } from '@redux/services/revertMatchService';

const initialState = {
    isSubmitting: false,
};

const revertMatchSlice = createSlice({
    name: 'revertMatch',
    initialState,
    reducers: {
        clearAlert(state) {
        },
    },
    extraReducers: (builder) => {


        // process Match Winner
        builder.addMatcher(isAnyOf(revertMatchAsync.pending), (state) => {
            state.isSubmitting = true;
        });
        builder.addMatcher(isAnyOf(revertMatchAsync.fulfilled), (state) => {
            state.isSubmitting = false;
        });
        builder.addMatcher(isAnyOf(revertMatchAsync.rejected), (state) => {
            state.isSubmitting = false;
        });
    },
});

export default revertMatchSlice.reducer;
