import { getBonusSummaryAsync } from '@redux/services/bonusSummaryService';
import { createSlice, isAnyOf } from '@reduxjs/toolkit';

const initialState = {
  isLoading: false,
  isSubmitting: false,
  isDeleting: false,
  bonusSummary: {},
};

const bonusSummarySlice = createSlice({
  name: 'bonus-summary',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    // Get Bonus Test Summary ----------
    builder.addMatcher(isAnyOf(getBonusSummaryAsync.pending), (state, { payload }) => {
      state.isLoading = true;
      state.dashboardList = [];
    });
    builder.addMatcher(isAnyOf(getBonusSummaryAsync.fulfilled), (state, { payload }) => {
      state.isLoading = false;
      state.bonusSummary = payload?.body;
    });
    builder.addMatcher(isAnyOf(getBonusSummaryAsync.rejected), (state, { payload }) => {
      state.isLoading = false;
      state.bonusSummary = {};
    });
    // -------------
  },
});

export default bonusSummarySlice.reducer;
