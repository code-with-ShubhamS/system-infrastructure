import { getTransactionAsync, postPaymentPartialAproveAsync, postPaymentStatusAsync } from '@redux/services/transaction';
import { createSlice, isAnyOf } from '@reduxjs/toolkit';

const initialState = {
  isLoading: false,
  isSubmitting: false,
  isDeleting: false,
  transactions: [],
  totalCount: 0,
  userDetails:{},
  isPaymentWalletBallanceLoading: false,
};

const transactionsSlice = createSlice({
  name: 'transactions',
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    // Get Users ----------
    builder.addMatcher(isAnyOf(getTransactionAsync.pending), (state, { payload }) => {
      state.isLoading = true;
    });
    builder.addMatcher(isAnyOf(getTransactionAsync.fulfilled), (state, { payload }) => {
      state.isLoading = false;
      state.transactions = payload.body?.content || 0;
      state.totalCount = payload.body?.totalElements || 0;
     ;
    });
    builder.addMatcher(isAnyOf(getTransactionAsync.rejected), (state, { payload }) => {
      state.isLoading = false;
      state.transactions = [];
    });
    // -------------


    // Update Payment status ----------
    builder.addMatcher(isAnyOf(postPaymentStatusAsync.pending), (state, { payload }) => {
      state.isPaymentWalletBallanceLoading = true;
    });
    builder.addMatcher(isAnyOf(postPaymentStatusAsync.fulfilled), (state, { payload }) => {
      state.isPaymentWalletBallanceLoading = false;
     ;
    });
    builder.addMatcher(isAnyOf(postPaymentStatusAsync.rejected), (state, { payload }) => {
      state.isPaymentWalletBallanceLoading = false;
    });
    // -------------

    // Update Payment status ----------
    builder.addMatcher(isAnyOf(postPaymentPartialAproveAsync.pending), (state, { payload }) => {
      state.isPaymentWalletBallanceLoading = true;
    });
    builder.addMatcher(isAnyOf(postPaymentPartialAproveAsync.fulfilled), (state, { payload }) => {
      state.isPaymentWalletBallanceLoading = false;
     ;
    });
    builder.addMatcher(isAnyOf(postPaymentPartialAproveAsync.rejected), (state, { payload }) => {
      state.isPaymentWalletBallanceLoading = false;
    });
    // -------------

   

  },
});

export const { clearAlert } = transactionsSlice.actions;
export default transactionsSlice.reducer;
