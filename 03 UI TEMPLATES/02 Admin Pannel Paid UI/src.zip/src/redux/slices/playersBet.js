// src/redux/slices/playersBetSlice.js
import { createSlice, isAnyOf } from '@reduxjs/toolkit';
import { getPlayersBetAsync, processMatchWinnerAsync, postFancyWinnerAsync, updateMarketStatusAsync, updateMatchStatusAsync, setFancyDefaultAsync, betRejectAsync, setMatchLimitAsync } from '@redux/services/playersBet';

const initialState = {
    isLoading: false,
    isSubmitting: false,
    isDeleting: false,
    playersBet: [],
    playersBetById: {},
    isfancyDefaultLoading: false,
    count: 0,
    betRejectLoading: false,
    matchLimitLoading: false,
};

const playersBetSlice = createSlice({
    name: 'playersBet',
    initialState,
    reducers: {
        clearAlert(state) {
        },
    },
    extraReducers: (builder) => {
        // Get All PlayersBets
        builder.addMatcher(isAnyOf(getPlayersBetAsync.pending), (state) => {
            state.isLoading = true;
        });
        builder.addMatcher(isAnyOf(getPlayersBetAsync.fulfilled), (state, { payload }) => {
            state.isLoading = false;
            state.playersBet = payload?.body.content;
            state.count = payload?.body.totalElements;
        });
        builder.addMatcher(isAnyOf(getPlayersBetAsync.rejected), (state) => {
            state.isLoading = false;
        });

        // Get All PlayersBets
        builder.addMatcher(isAnyOf(betRejectAsync.pending), (state) => {
            state.betRejectLoading = true;
        });
        builder.addMatcher(isAnyOf(betRejectAsync.fulfilled), (state, { payload }) => {
            state.betRejectLoading = false;
        });
        builder.addMatcher(isAnyOf(betRejectAsync.rejected), (state) => {
            state.betRejectLoading = false;
        });

        // Set Match Limit
        builder.addMatcher(isAnyOf(setMatchLimitAsync.pending), (state) => {
            state.matchLimitLoading = true;
        });
        builder.addMatcher(isAnyOf(setMatchLimitAsync.fulfilled), (state, { payload }) => {
            state.matchLimitLoading = false;
        });
        builder.addMatcher(isAnyOf(setMatchLimitAsync.rejected), (state) => {
            state.matchLimitLoading = false;
        });


        // process Match Winner
        builder.addMatcher(isAnyOf(processMatchWinnerAsync.pending), (state) => {
            state.isSubmitting = true;
        });
        builder.addMatcher(isAnyOf(processMatchWinnerAsync.fulfilled), (state) => {
            state.isSubmitting = false;
        });
        builder.addMatcher(isAnyOf(processMatchWinnerAsync.rejected), (state) => {
            state.isSubmitting = false;
        });


        // post Bet Settelment
        builder.addMatcher(isAnyOf(postFancyWinnerAsync.pending), (state) => {
            state.isSubmitting = true;
        });
        builder.addMatcher(isAnyOf(postFancyWinnerAsync.fulfilled), (state) => {
            state.isSubmitting = false;
        });
        builder.addMatcher(isAnyOf(postFancyWinnerAsync.rejected), (state) => {
            state.isSubmitting = false;
        });

        // Update Market Status
        builder.addMatcher(isAnyOf(updateMarketStatusAsync.pending), (state) => {
            state.isSubmitting = true;
        });
        builder.addMatcher(isAnyOf(updateMarketStatusAsync.fulfilled), (state) => {
            state.isSubmitting = false;
        });
        builder.addMatcher(isAnyOf(updateMarketStatusAsync.rejected), (state) => {
            state.isSubmitting = false;
        });
        
        // Update match Status
        builder.addMatcher(isAnyOf(updateMatchStatusAsync.pending), (state) => {
            state.isSubmitting = true;
        });
        builder.addMatcher(isAnyOf(updateMatchStatusAsync.fulfilled), (state) => {
            state.isSubmitting = false;
        });
        builder.addMatcher(isAnyOf(updateMatchStatusAsync.rejected), (state) => {
            state.isSubmitting = false;
        });

        // Set fancy default
        builder.addMatcher(isAnyOf(setFancyDefaultAsync.pending), (state) => {
            state.isfancyDefaultLoading = true;
        });
        builder.addMatcher(isAnyOf(setFancyDefaultAsync.fulfilled), (state) => {
            state.isfancyDefaultLoading = false;
        });
        builder.addMatcher(isAnyOf(setFancyDefaultAsync.rejected), (state) => {
            state.isfancyDefaultLoading = false;
        });
    },
});

export default playersBetSlice.reducer;
