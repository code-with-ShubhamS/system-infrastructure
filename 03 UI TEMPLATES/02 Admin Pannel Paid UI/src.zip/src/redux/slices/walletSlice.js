import { getWalletBalanceAsync } from '@redux/services/walletService';
import { createSlice, isAnyOf } from '@reduxjs/toolkit';

const initialState = {
  isLoading: false,
  walletBalance: {},
};

const walletSlice = createSlice({
  name: 'wallet',
  initialState,
  reducers: {
  },
  extraReducers: (builder) => {
    // Get Wallet Balance ----------
    builder.addMatcher(isAnyOf(getWalletBalanceAsync.pending), (state) => {
      state.isLoading = true;
    });
    builder.addMatcher(isAnyOf(getWalletBalanceAsync.fulfilled), (state, { payload }) => {
      state.isLoading = false;
      state.walletBalance = payload.body;
     ;
    });
    builder.addMatcher(isAnyOf(getWalletBalanceAsync.rejected), (state) => {
      state.isLoading = false;
      state.walletBalance = {};
    });
    // -------------

  },
});

export default walletSlice.reducer;
