import { getStatsAsync } from '@redux/services/statsService';
import { createSlice, isAnyOf } from '@reduxjs/toolkit';

const initialState = {
  isLoading: false,
  statsData: {},
};

const statsSlice = createSlice({
  name: 'stats',
  initialState,
  reducers: {
    clearStatsData(state) {
      state.statsData = {};
    }
  },
  extraReducers: (builder) => {
    // Get Stats ----------
    builder.addMatcher(isAnyOf(getStatsAsync.pending), (state) => {
      state.isLoading = true;
    });
    builder.addMatcher(isAnyOf(getStatsAsync.fulfilled), (state, { payload }) => {
      state.isLoading = false;
      state.statsData = payload.body;
     ;
    });
    builder.addMatcher(isAnyOf(getStatsAsync.rejected), (state) => {
      state.isLoading = false;
      state.statsData = {};
    });
    // -------------

  },
});

export const { clearStatsData } = statsSlice.actions;
export default statsSlice.reducer;
