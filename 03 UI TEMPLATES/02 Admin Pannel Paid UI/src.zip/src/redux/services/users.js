import { createAsyncThunk } from '@reduxjs/toolkit';
import AxiosClient from '@utils/axios';

export const getUsersAsync = createAsyncThunk('users/getUsersAsync', async (params, toolkit) =>
  AxiosClient({
    toolkit,
    url: '/admin/get-player-by-adminId',
    method: 'get',
    params,
  })
);

export const getActiveUsersAsync = createAsyncThunk('users/getActiveUsersAsync', async (params, toolkit) =>
  AxiosClient({
    toolkit,
    url: '/admin/active-users',
    method: 'get',
    params,
  })
);

export const addUserAsync = createAsyncThunk('users/addUsersAsync', async (data, toolkit) =>
  AxiosClient({
    toolkit,
    url: '/admin/create-player',
    method: 'post',
    data,
  })
);
export const editUserAsync = createAsyncThunk('users/addUsersAsync', async ({data, id}, toolkit) =>
  AxiosClient({
    toolkit,
    url: `/admin/edit-players/${id}`,
    method: 'put',
    data,
  })
);

// get user Amount //

export const postCreditAsync = createAsyncThunk('usersAmount/admin/payment/credit', async (data, toolkit) =>
  AxiosClient({
    toolkit,
    url: '/admin/payment/credit',
    method: 'post',
    data,
  })
);

// get user Withdrawal //
export const postDebitAmountAsync = createAsyncThunk('usersDebit/admin/payment/debit', async (data, toolkit) =>
  AxiosClient({
    toolkit,
    url: '/admin/payment/debit',
    method: 'post',
    data,
  })
);



export const getUsersDetailsByIdAsync = createAsyncThunk('users/getUsersDetailsByIdAsync', async (id, toolkit) =>
  AxiosClient({
    toolkit,
    url: `/admin/profile/${id}`,
    method: 'get',
  })
);

export const getRelationShipManagerAsync = createAsyncThunk('users/getRelationShipManagerAsync', async (id, toolkit) =>
  AxiosClient({
    toolkit,
    url: `/admin/get-rm-sales-agent?type=RELATIONSHIP_MANAGER`,
    method: 'get',
  })
);

export const getSalesAgentAsync = createAsyncThunk('users/getSalesAgentAsync', async (id, toolkit) =>
  AxiosClient({
    toolkit,
    url: `/admin/get-rm-sales-agent?type=SALES_AGENT`,
    method: 'get',
  })
);