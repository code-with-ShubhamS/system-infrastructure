import { createAsyncThunk } from '@reduxjs/toolkit';
import AxiosClient from '@utils/axios';

export const getWalletBalanceAsync = createAsyncThunk(
  'get/getWalletBalanceAsync',
  async (params, toolkit) =>
    AxiosClient({
      toolkit,
      url: '/admin/get-total-wallet-balance',
      method: 'get',
      params,
    })
);
