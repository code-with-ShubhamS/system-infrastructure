import { createAsyncThunk } from '@reduxjs/toolkit';
import AxiosClient from '@utils/axios';

export const getStatsAsync = createAsyncThunk(
  'get/getStatsAsync',
  async (params, toolkit) =>
    AxiosClient({
      toolkit,
      url: '/admin/sales-agent-rm/dashboard',
      method: 'get',
      params,
    })
);
