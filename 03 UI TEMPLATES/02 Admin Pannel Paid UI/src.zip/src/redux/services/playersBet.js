// src/redux/services.js
import { createAsyncThunk } from '@reduxjs/toolkit';
import AxiosClient from '@utils/axios';

export const getPlayersBetAsync = createAsyncThunk('playersBet/getPlayersBetAsync', async (params, toolkit) =>
  AxiosClient({
    toolkit,
    url: '/admin/get-all-user-bets-by-admin',
    method: 'get',
    params
  })
);

export const processMatchWinnerAsync = createAsyncThunk('playersBet/processMatchWinnerAsync', async (data, toolkit) =>
  AxiosClient({
    toolkit,
    url: `/admin/process-winners`,
    method: 'post',
    data
  })
);

export const postFancyWinnerAsync = createAsyncThunk('fancyWinner/postFancyWinnerAsync', async (data, toolkit) =>
  AxiosClient({
    toolkit,
    url: '/admin/settle-bets',
    method: 'post',
    data
  })
);

export const updateMarketStatusAsync = createAsyncThunk('marketStatus/updateMarketStatusAsync', async (data, toolkit) =>
  AxiosClient({
    toolkit,
    url: `/admin/is-enabled/market`,
    method: 'put',
    data
  })
);
export const updateMatchStatusAsync = createAsyncThunk('matchStatus/updateMatchStatusAsync', async (data, toolkit) =>
  AxiosClient({
    toolkit,
    url: `/admin/is-enabled/match`,
    method: 'put',
    data
  })
);

export const setMatchLimitAsync = createAsyncThunk('matchStatus/setMatchLimitAsync', async ({id, data}, toolkit) =>{
  console.log("id",id)
  console.log("data",data)
 return AxiosClient({
    toolkit,
    url: `/admin/set-match-limit/${id}`,
    method: 'post',
    params: data
  })}
);

export const setFancyDefaultAsync = createAsyncThunk('matchStatus/setFancyDefaultAsync', async ({id, data}, toolkit) =>{
  console.log("id",id)
  console.log("data",data)
 return AxiosClient({
    toolkit,
    url: `/admin/set-default-fancy/${id}`,
    method: 'post',
    params: data
  })}
);
export const betRejectAsync = createAsyncThunk('matchStatus/betRejectAsync', async (id, toolkit) =>
  AxiosClient({
    toolkit,
    url: `/admin/reject-bet/${id}`,
    method: 'post',
  })
);
