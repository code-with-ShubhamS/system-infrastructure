import { createAsyncThunk } from '@reduxjs/toolkit';
import AxiosClient from '@utils/axios';

export const getBonusSummaryAsync = createAsyncThunk(
  'get/getBonusSummaryAsync',
  async (params, toolkit) =>
    AxiosClient({
      toolkit,
      url: '/admin/transactions/bonus-test-summary',
      method: 'get',
      params,
    })
);
