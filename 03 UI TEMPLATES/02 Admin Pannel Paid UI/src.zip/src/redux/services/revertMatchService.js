// src/redux/services.js
import { createAsyncThunk } from '@reduxjs/toolkit';
import AxiosClient from '@utils/axios';

export const revertMatchAsync = createAsyncThunk('revertMatch/revertMatchAsync', async (params, toolkit) =>
  AxiosClient({
    toolkit,
    url: `/admin/revert`,
    method: 'post',
    params
  })
);