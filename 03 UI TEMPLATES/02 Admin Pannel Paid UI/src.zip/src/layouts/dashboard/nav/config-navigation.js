// routes
import { PATH_DASHBOARD }from '../../../routes/paths';
// components
import SvgColor from '../../../components/svg-color';

// ----------------------------------------------------------------------

const icon = (name) => (
  <SvgColor src={`/assets/icons/navbar/${name}.svg`} sx={{ width: 1, height: 1 }} />
);

const ICONS = {
  dashboard: icon('dashboard'),
  chatbot: icon('chatbot'),
  home: icon('home'),
  loss: icon('loss'),
  players: icon('players'),
  win: icon('win'),
  management: icon('management'),
  admin: icon('admin'),
  matchwinner: icon('matchwinner'),
  matchstatus: icon('matchstatus'),
  totalloss: icon('totalloss'),
  marketstatus: icon('marketstatus'),
  fancywinner: icon('fancywinner'),
  activeUser: icon('activeUser'),
  transections: icon('transections'),
  wallet: icon('wallet'),
  bonus: icon('bonus'),
  chart: icon('chart'),
  revertmatch: icon('revertMatch'),
};

const superAdminConfig = [
  {
    items: [
      {
        title: 'Dashboard',
        path: PATH_DASHBOARD.main.root,
        icon: ICONS.dashboard,
      },
      {
        title: 'Sales Stats',
        path: PATH_DASHBOARD.stats.root,
        icon: ICONS.chart
      },
      {
        title: 'User Management',
        path: PATH_DASHBOARD.user.root,
        icon: ICONS.management,
      },
      {
        title: 'Active User',
        path: PATH_DASHBOARD.activeUser.root,
        icon: ICONS.activeUser,
      },
      {
        title: 'Admin',
        path: PATH_DASHBOARD.admin.root,
        icon: ICONS.admin,
      },
      {
        title: 'Players bet',
        path: PATH_DASHBOARD.playersbet.root,
        icon: ICONS.players
      },
      {
        title: 'Match Result',
        path: PATH_DASHBOARD.TotalWin.root,
        icon: ICONS.win
      },
      {
        title: 'Fancy Result',
        path: PATH_DASHBOARD.totalLoss.root,
        icon: ICONS.totalloss
      },
      {
        title: 'Match Winner',
        path: PATH_DASHBOARD.matchWiner.root,
        icon: ICONS.matchwinner
      },
      {
        title: 'Fancy Winner',
        path: PATH_DASHBOARD.fancyWiner.root,
        icon: ICONS.fancywinner
      },
      {
        title: 'Market Status',
        path: PATH_DASHBOARD.marketStatus.root,
        icon: ICONS.marketstatus
      },
      {
        title: 'Match Status',
        path: PATH_DASHBOARD.matchStatus.root,
        icon: ICONS.matchstatus
      },
      {
        title: 'Revert Match',
        path: PATH_DASHBOARD.revertMatch.root,
        icon: ICONS.revertmatch,
      },
      
      {
        title: 'Transaction',
        path: PATH_DASHBOARD.transaction.root,
        icon: ICONS.transections
      },
      {
        title: 'Bonus Transaction List',
        path: PATH_DASHBOARD.bonusSummary.root,
        icon: ICONS.bonus
      },
      {
        title: 'Wallet Ballance',
        path: PATH_DASHBOARD.walletBallance.root,
        icon: ICONS.wallet
      },
    ],
  },
];


const NavConfig = [
  {
    items: [
      {
        title: 'Sales Stats',
        path: PATH_DASHBOARD.stats.root,
        icon: ICONS.chart
      },
      {
        title: 'User Management',
        path: PATH_DASHBOARD.user.root,
        icon: ICONS.management,
      },
      {
        title: 'Active User',
        path: PATH_DASHBOARD.activeUser.root,
        icon: ICONS.activeUser,
      },
      {
        title: 'Players bet',
        path: PATH_DASHBOARD.playersbet.root,
        icon: ICONS.players
      },
      {
        title: 'Match Result',
        path: PATH_DASHBOARD.TotalWin.root,
        icon: ICONS.win
      },
      {
        title: 'Fancy Result',
        path: PATH_DASHBOARD.totalLoss.root,
        icon: ICONS.totalloss
      },      
      {
        title: 'Transaction',
        path: PATH_DASHBOARD.transaction.root,
        icon: ICONS.matchstatus
      },
            {
        title: 'Bonus Transaction List',
        path: PATH_DASHBOARD.bonusSummary.root,
        icon: ICONS.bonus
      },
      {
        title: 'Wallet Ballance',
        path: PATH_DASHBOARD.walletBallance.root,
        icon: ICONS.wallet
      },
    ],
  },
];

const superAdminReadOperatorConfig = [
  {
    items: [
      {
        title: 'User Management',
        path: PATH_DASHBOARD.user.root,
        icon: ICONS.management,
      },
      {
        title: 'Players bet',
        path: PATH_DASHBOARD.playersbet.root,
        icon: ICONS.players
      },     
      {
        title: 'Transaction',
        path: PATH_DASHBOARD.transaction.root,
        icon: ICONS.matchstatus
      },
    ],
  },
];

export  {superAdminConfig, NavConfig, superAdminReadOperatorConfig};
