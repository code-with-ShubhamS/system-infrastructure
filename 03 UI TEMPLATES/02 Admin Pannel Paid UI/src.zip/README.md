# odds-admin-panel
Admin Panel for ODDS Project - Sagar Sharma






<!-- <Controller
                name="calendarYearEndsAt"
                control={control}
                rules={{ required: 'This is a required field.' }}
                render={({ field: { value, onChange }, fieldState: { error } }) => (
                  <AppReactDatepicker
                    selected={value}
                    onChange={onChange}
                    dateFormat='dd/MMM/yyyy'
                    customInput={
                      <TextField
                        value={value}
                        onChange={onChange}
                        fullWidth
                        sx={{ width: '100%' }}
                        label="Company Calendar Year (To)"
                        error={error}
                        helperText={error?.message}
                         InputProps={{
                            endAdornment: (
                             <InputAdornment position="start">
                               <Iconify icon="uiw:date" sx={{ color: 'text.disabled' }} />
                             </InputAdornment>
                            ),
                        }}
                      />
                    }
                  />
                )}
              /> -->

               <!-- <AppReactDatepicker
                    selected={value}
                    onChange={onChange}
                    dateFormat='dd/MMM/yyyy'
                    customInput={
                      <TextField
                        value={value}
                        onChange={onChange}
                        fullWidth
                        sx={{ width: '100%' }}
                        label="Company Calendar Year (To)"
                         InputProps={{
                            endAdornment: (
                             <InputAdornment position="start">
                               <Iconify icon="uiw:date" sx={{ color: 'text.disabled' }} />
                             </InputAdornment>
                            ),
                        }}
                      />
                    }
                  /> -->